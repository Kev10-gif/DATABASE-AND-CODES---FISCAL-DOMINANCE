# ============================================================
# RUN_ALL.R
# Archivo de ejecución con un click.
# Abre este archivo en RStudio y presiona Source.
# ============================================================

rm(list = ls())

# Intenta fijar el working directory automáticamente en la carpeta donde está RUN_ALL.R.
# Esto ayuda cuando presionas Source desde RStudio sin crear un proyecto.
if (interactive() && requireNamespace("rstudioapi", quietly = TRUE)) {
  this_path <- tryCatch(rstudioapi::getActiveDocumentContext()$path, error = function(e) "")
  if (!is.null(this_path) && nzchar(this_path)) setwd(dirname(normalizePath(this_path)))
}

message("Working directory actual: ", getwd())
message("Archivos detectados en la carpeta:")
print(list.files())

source("00_setup_data.R")
source("01_table_1_advanced.R")
source("02_table_2_emerging.R")
source("03_table_3_CBI.R")
source("04_table_4_FI.R")

writexl::write_xlsx(
  list(
    "Quality checks" = quality_checks,
    "T1 Panel A" = panelA_table1,
    "T1 Panel B" = panelB_table1,
    "T1 Fit" = fit_table1,
    "T2 Panel A" = panelA_table2,
    "T2 Panel B" = panelB_table2,
    "T2 Fit" = fit_table2,
    "T3a Panel A" = table3a$panelA,
    "T3a Panel B" = table3a$panelB,
    "T3a Fit" = table3a$fit,
    "T3b Panel A" = table3b$panelA,
    "T3b Panel B" = table3b$panelB,
    "T3b Fit" = table3b$fit,
    "T4a Panel A" = table4a$panelA,
    "T4a Panel B" = table4a$panelB,
    "T4a Fit" = table4a$fit,
    "T4b Panel A" = table4b$panelA,
    "T4b Panel B" = table4b$panelB,
    "T4b Fit" = table4b$fit
  ),
  file.path(out_dir, "ALL_TABLES_REPLICATION_RESULTS.xlsx")
)

message("============================================================")
message("Replication complete.")
message("Archivo principal: outputs/ALL_TABLES_REPLICATION_RESULTS.xlsx")
message("También se guardaron Excel/CSV individuales en /outputs.")
message("============================================================")
