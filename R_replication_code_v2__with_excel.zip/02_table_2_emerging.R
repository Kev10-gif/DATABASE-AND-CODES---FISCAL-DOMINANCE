# ============================================================
# 02_table_2_emerging.R
# Tabla 2: Augmented Taylor Rule - Emerging Economies
# ============================================================
if (!exists("emerging") || !exists("debt_percentiles")) source("00_setup_data.R")

specs_table2 <- c(
  "mpr_lag1 + inflation + ggdp",
  "mpr_lag1 + inflation + ggdp + GD",
  "mpr_lag1 + inflation + output_gap",
  "mpr_lag1 + inflation + output_gap + GD",
  "mpr_lag1 + inflation + output_gap + GD + debt_x_inf",
  "mpr_lag1 + inflation + output_gap + dner + GD + debt_x_inf",
  "mpr_lag1 + inflation + ggdp + GD + debt_x_inf",
  "mpr_lag1 + inflation + ggdp + dner + GD + debt_x_inf"
)

models_table2 <- purrr::imap(specs_table2, ~ run_fe(emerging, .x))

panelA_table2 <- purrr::imap_dfr(models_table2, function(m, i) {
  long_run_table(m, paste0("Table 2 model ", i)) %>% mutate(model = i, sample = "Emerging")
}) %>% select(sample, model, term_label, term, reported_scale, estimate, std.error, statistic, p.value, stars)

panelB_table2 <- purrr::imap_dfr(models_table2[5:8], function(m, i) {
  true_model <- i + 4
  phi_at_debt(m, debt_percentiles$emerging, paste0("Table 2 model ", true_model)) %>%
    mutate(model = true_model, sample = "Emerging")
}) %>% select(sample, model, debt_percentile, debt_value, estimate, std.error, statistic, p.value, stars)

fit_table2 <- fit_stats(models_table2)

save_outputs("table2_emerging", panelA_table2, panelB_table2, fit_table2)

writexl::write_xlsx(
  list(
    "Panel A long-run effects" = panelA_table2,
    "Panel B Phi at debt" = panelB_table2,
    "Fit statistics" = fit_table2,
    "Quality checks" = quality_checks
  ),
  file.path(out_dir, "table2_emerging.xlsx")
)

message("Tabla 2 completa. Resultados guardados en /outputs.")
