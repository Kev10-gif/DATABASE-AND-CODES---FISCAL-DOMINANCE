# ============================================================
# 01_table_1_advanced.R
# Tabla 1: Augmented Taylor Rule - Advanced Economies
# ============================================================
if (!exists("advanced") || !exists("debt_percentiles")) source("00_setup_data.R")

specs_table1 <- c(
  "mpr_lag1 + inflation + ggdp",
  "mpr_lag1 + inflation + ggdp + GD",
  "mpr_lag1 + inflation + output_gap",
  "mpr_lag1 + inflation + output_gap + GD",
  "mpr_lag1 + inflation + output_gap + GD + debt_x_inf",
  "mpr_lag1 + inflation + output_gap + dner + GD + debt_x_inf",
  "mpr_lag1 + inflation + ggdp + GD + debt_x_inf",
  "mpr_lag1 + inflation + ggdp + dner + GD + debt_x_inf"
)

models_table1 <- purrr::imap(specs_table1, ~ run_fe(advanced, .x))

panelA_table1 <- purrr::imap_dfr(models_table1, function(m, i) {
  long_run_table(m, paste0("Table 1 model ", i)) %>% mutate(model = i, sample = "Advanced")
}) %>% select(sample, model, term_label, term, reported_scale, estimate, std.error, statistic, p.value, stars)

panelB_table1 <- purrr::imap_dfr(models_table1[5:8], function(m, i) {
  true_model <- i + 4
  phi_at_debt(m, debt_percentiles$advanced, paste0("Table 1 model ", true_model)) %>%
    mutate(model = true_model, sample = "Advanced")
}) %>% select(sample, model, debt_percentile, debt_value, estimate, std.error, statistic, p.value, stars)

fit_table1 <- fit_stats(models_table1)

save_outputs("table1_advanced", panelA_table1, panelB_table1, fit_table1)

writexl::write_xlsx(
  list(
    "Panel A long-run effects" = panelA_table1,
    "Panel B Phi at debt" = panelB_table1,
    "Fit statistics" = fit_table1,
    "Quality checks" = quality_checks
  ),
  file.path(out_dir, "table1_advanced.xlsx")
)

message("Tabla 1 completa. Resultados guardados en /outputs.")
