# ============================================================
# 04_table_4_FI.R
# Tabla 4a y Tabla 4b: Financial Integration como moderador
# ============================================================
if (!exists("advanced") || !exists("emerging") || !exists("debt_percentiles")) source("00_setup_data.R")

make_table4 <- function(data, debt_values, sample_name, prefix) {
  # En el Excel la variable se llama IF; en el paper se reporta como FI / financial integration.
  specs_fi <- c(
    "mpr_lag1 + inflation + ggdp + dner + GD + debt_x_inf + debt_x_inf_IF",
    "mpr_lag1 + inflation + output_gap + dner + GD + debt_x_inf + debt_x_inf_IF",
    "mpr_lag1 + inflation + ggdp + GD + debt_x_inf + debt_x_inf_IF",
    "mpr_lag1 + inflation + output_gap + GD + debt_x_inf + debt_x_inf_IF"
  )

  models <- purrr::imap(specs_fi, ~ run_fe(data, .x))

  panelA <- purrr::imap_dfr(models, function(m, i) {
    long_run_table(m, paste0(prefix, " model ", i)) %>% mutate(model = i, sample = sample_name)
  }) %>% select(sample, model, term_label, term, reported_scale, estimate, std.error, statistic, p.value, stars)

  panelB <- purrr::imap_dfr(models, function(m, i) {
    slope_differential(m, debt_values, "debt_x_inf_IF", paste0(prefix, " model ", i)) %>%
      mutate(model = i, sample = sample_name,
             differential = "Delta Phi(b): high FI minus low FI")
  }) %>% select(sample, model, differential, debt_percentile, debt_value, estimate, std.error, statistic, p.value, stars)

  fit <- fit_stats(models)
  save_outputs(prefix, panelA, panelB, fit)

  writexl::write_xlsx(
    list(
      "Panel A long-run effects" = panelA,
      "Panel B Delta Phi" = panelB,
      "Fit statistics" = fit,
      "Quality checks" = quality_checks
    ),
    file.path(out_dir, paste0(prefix, ".xlsx"))
  )

  invisible(list(models = models, panelA = panelA, panelB = panelB, fit = fit))
}

table4a <- make_table4(advanced, debt_percentiles$advanced, "Advanced", "table4a_FI_advanced")
table4b <- make_table4(emerging, debt_percentiles$emerging, "Emerging", "table4b_FI_emerging")

message("Tabla 4a y 4b completas. Resultados guardados en /outputs.")
