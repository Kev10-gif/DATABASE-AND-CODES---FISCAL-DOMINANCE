# ============================================================
# 03_table_3_CBI.R
# Tabla 3a y Tabla 3b: Central Bank Independence como moderador
# ============================================================
if (!exists("advanced") || !exists("emerging") || !exists("debt_percentiles")) source("00_setup_data.R")

make_table3 <- function(data, debt_values, sample_name, prefix) {
  specs_cbi <- c(
    "mpr_lag1 + inflation + ggdp + dner + GD + debt_x_inf + debt_x_inf_CBI",
    "mpr_lag1 + inflation + output_gap + dner + GD + debt_x_inf + debt_x_inf_CBI",
    "mpr_lag1 + inflation + ggdp + GD + debt_x_inf + debt_x_inf_CBI",
    "mpr_lag1 + inflation + output_gap + GD + debt_x_inf + debt_x_inf_CBI"
  )

  models <- purrr::imap(specs_cbi, ~ run_fe(data, .x))

  panelA <- purrr::imap_dfr(models, function(m, i) {
    long_run_table(m, paste0(prefix, " model ", i)) %>% mutate(model = i, sample = sample_name)
  }) %>% select(sample, model, term_label, term, reported_scale, estimate, std.error, statistic, p.value, stars)

  panelB <- purrr::imap_dfr(models, function(m, i) {
    slope_differential(m, debt_values, "debt_x_inf_CBI", paste0(prefix, " model ", i)) %>%
      mutate(model = i, sample = sample_name,
             differential = "Delta Phi(b): high CBI minus low CBI")
  }) %>% select(sample, model, differential, debt_percentile, debt_value, estimate, std.error, statistic, p.value, stars)

  fit <- fit_stats(models)
  save_outputs(prefix, panelA, panelB, fit)

  writexl::write_xlsx(
    list(
      "Panel A long-run effects" = panelA,
      "Panel B Delta Phi" = panelB,
      "Fit statistics" = fit,
      "Quality checks" = quality_checks
    ),
    file.path(out_dir, paste0(prefix, ".xlsx"))
  )

  invisible(list(models = models, panelA = panelA, panelB = panelB, fit = fit))
}

table3a <- make_table3(advanced, debt_percentiles$advanced, "Advanced", "table3a_CBI_advanced")
table3b <- make_table3(emerging, debt_percentiles$emerging, "Emerging", "table3b_CBI_emerging")

message("Tabla 3a y 3b completas. Resultados guardados en /outputs.")
