# ============================================================
# 00_setup_data.R
# Preparación de datos y funciones comunes para las Tablas 1, 2, 3a-3b y 4a-4b
# Paper: augmented panel Taylor rules / fiscal dominance
# ============================================================

# ---------------- PAQUETES ----------------
required_packages <- c(
  "readxl", "dplyr", "tidyr", "stringr", "zoo", "plm",
  "mFilter", "purrr", "tibble", "lmtest", "sandwich", "writexl"
)

install_if_missing <- function(pkgs) {
  missing <- pkgs[!vapply(pkgs, requireNamespace, quietly = TRUE, FUN.VALUE = logical(1))]
  if (length(missing) > 0) install.packages(missing, dependencies = TRUE)
}
install_if_missing(required_packages)

suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(zoo)
  library(plm)
  library(mFilter)
  library(purrr)
  library(tibble)
  library(lmtest)
  library(sandwich)
  library(writexl)
})

# ---------------- CONFIGURACIÓN DEL USUARIO ----------------
# El Excel debe llamarse exactamente así y estar en esta misma carpeta.
file_xlsx <- "PANEL1_COMPLETO(1).xlsx"
out_dir   <- "outputs"
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

# Parámetro estándar del filtro HP para datos trimestrales.
hp_lambda <- 1600

# FALSE: recalcula output gap en R con HP sobre log(GDP), que es lo mejor para un replication package.
# TRUE : usa la columna OUTPUTGAP del Excel, útil si quieres acercarte más al workfile original de EViews.
USE_EXCEL_OUTPUTGAP <- FALSE

# Método de varianza-covarianza.
# "pcse" = Beck-Katz / PCSE con plm::vcovBK.
# "white_period" = Arellano-HC1 cluster por tiempo; alternativa si quieres aproximarte al wording de EViews White-period.
VCOV_METHOD <- "pcse"

# ---------------- FUNCIONES AUXILIARES: DATA ----------------
stop_if_missing_file <- function(path) {
  if (!file.exists(path)) {
    stop(paste0(
      "No encontré el Excel: ", path, "\n",
      "Coloca PANEL1_COMPLETO(1).xlsx en la misma carpeta de los scripts, ",
      "o cambia file_xlsx en 00_setup_data.R."
    ), call. = FALSE)
  }
}

get_sheet_name <- function(target) {
  sheets <- readxl::excel_sheets(file_xlsx)
  hit <- sheets[tolower(sheets) == tolower(target)]
  if (length(hit) == 0) {
    stop(paste0("No encontré la pestaña '", target, "'. Pestañas disponibles: ", paste(sheets, collapse = ", ")), call. = FALSE)
  }
  hit[[1]]
}

parse_qtr <- function(x) {
  zoo::as.yearqtr(toupper(as.character(x)), format = "%YQ%q")
}

standardize_names <- function(df) {
  df %>%
    rename_with(~ str_trim(.x)) %>%
    rename_with(~ str_replace_all(.x, "\\s+", "_")) %>%
    rename_with(~ str_replace_all(.x, "[^A-Za-z0-9_]", "_"))
}

required_cols <- c("country", "country_code", "quarter", "mpr", "IPC", "GDP", "NER", "GD", "IF", "CBI")

check_required_cols <- function(df, sheet_name) {
  missing_cols <- setdiff(required_cols, names(df))
  if (length(missing_cols) > 0) {
    stop(paste0("La pestaña '", sheet_name, "' no tiene estas columnas requeridas: ", paste(missing_cols, collapse = ", ")), call. = FALSE)
  }
}

safe_hp_cycle <- function(x, lambda = 1600) {
  x <- as.numeric(x)
  if (sum(!is.na(x)) < 8) return(rep(NA_real_, length(x)))
  ans <- tryCatch(
    as.numeric(mFilter::hpfilter(log(x), freq = lambda, type = "lambda")$cycle * 100),
    error = function(e) rep(NA_real_, length(x))
  )
  ans
}

get_debt_percentiles_raw <- function(sheet_target) {
  sheet_name <- get_sheet_name(sheet_target)
  raw <- readxl::read_excel(file_xlsx, sheet = sheet_name) %>% standardize_names()
  check_required_cols(raw, sheet_name)
  stats::quantile(as.numeric(raw$GD), probs = c(.25, .50, .75), na.rm = TRUE, names = TRUE)
}

make_panel <- function(sheet_target) {
  sheet_name <- get_sheet_name(sheet_target)
  raw <- readxl::read_excel(file_xlsx, sheet = sheet_name) %>% standardize_names()
  check_required_cols(raw, sheet_name)

  raw <- raw %>%
    mutate(
      sample_group = sheet_name,
      country      = as.factor(country),
      quarter      = parse_qtr(quarter),
      country_code = as.factor(country_code),
      IF           = as.numeric(IF),
      CBI          = as.numeric(CBI),
      GD           = as.numeric(GD),
      mpr          = as.numeric(mpr),
      IPC          = as.numeric(IPC),
      GDP          = as.numeric(GDP),
      NER          = as.numeric(NER),
      OUTPUTGAP    = if ("OUTPUTGAP" %in% names(.)) as.numeric(OUTPUTGAP) else NA_real_
    ) %>%
    arrange(country, quarter)

  out <- raw %>%
    group_by(country) %>%
    arrange(quarter, .by_group = TRUE) %>%
    mutate(
      # Transformaciones solicitadas:
      # inflación = 400 * Δlog(IPC)
      # depreciación = 400 * Δlog(NER)
      # crecimiento PBI = 400 * Δlog(GDP)
      inflation = 400 * (log(IPC) - dplyr::lag(log(IPC), 1)),
      dner      = 400 * (log(NER) - dplyr::lag(log(NER), 1)),
      ggdp      = 400 * (log(GDP) - dplyr::lag(log(GDP), 1)),
      outputgap_hp = safe_hp_cycle(GDP, hp_lambda),
      output_gap   = if (USE_EXCEL_OUTPUTGAP && any(!is.na(OUTPUTGAP))) OUTPUTGAP else outputgap_hp,
      mpr_lag1 = dplyr::lag(mpr, 1),
      debt_x_inf     = GD * inflation,
      debt_x_inf_CBI = GD * inflation * CBI,
      debt_x_inf_IF  = GD * inflation * IF
    ) %>%
    ungroup() %>%
    filter(!is.na(mpr), !is.na(mpr_lag1), !is.na(inflation), !is.na(output_gap),
           !is.na(ggdp), !is.na(dner), !is.na(GD), !is.na(CBI), !is.na(IF))

  plm::pdata.frame(out, index = c("country", "quarter"), drop.index = FALSE, row.names = TRUE)
}

# ---------------- FUNCIONES AUXILIARES: ESTIMACIÓN ----------------
run_fe <- function(data, rhs) {
  plm::plm(
    stats::as.formula(paste("mpr ~", rhs)),
    data   = data,
    model  = "within",
    effect = "individual"
  )
}

vcov_table <- function(model) {
  if (VCOV_METHOD == "pcse") {
    V <- tryCatch(
      plm::vcovBK(model, type = "HC1", cluster = "time", diagonal = FALSE),
      error = function(e) NULL
    )
    if (!is.null(V)) return(V)
    warning("vcovBK falló; uso vcovHC cluster por tiempo como fallback.")
  }
  plm::vcovHC(model, method = "arellano", type = "HC1", cluster = "time")
}

coef_required <- function(b, term, model_label = "modelo") {
  if (!(term %in% names(b))) {
    stop(paste0(
      "No encuentro el coeficiente '", term, "' en ", model_label, ".\n",
      "Coeficientes disponibles: ", paste(names(b), collapse = ", "), "\n",
      "Esto suele ocurrir si R eliminó una variable por colinealidad perfecta o si el nombre cambió."
    ), call. = FALSE)
  }
  b[[term]]
}

stars <- function(p) {
  dplyr::case_when(
    is.na(p) ~ "",
    p < 0.01 ~ "***",
    p < 0.05 ~ "**",
    p < 0.10 ~ "*",
    TRUE ~ ""
  )
}

clean_term <- function(x) {
  dplyr::recode(x,
    "mpr_lag1"       = "Interest rate smoothing",
    "inflation"      = "Inflation",
    "output_gap"     = "Output gap",
    "ggdp"           = "GDP growth",
    "dner"           = "ER depreciation",
    "GD"             = "Gross debt",
    "debt_x_inf"     = "Gross debt x inflation",
    "debt_x_inf_CBI" = "Gross debt x inflation x CBI",
    "debt_x_inf_IF"  = "Gross debt x inflation x FI",
    .default = x
  )
}

long_run_table <- function(model, model_label = "modelo") {
  b <- stats::coef(model)
  V <- vcov_table(model)
  rho <- coef_required(b, "mpr_lag1", model_label)

  smoothing <- tibble::tibble(
    term = "mpr_lag1",
    estimate = rho,
    std.error = sqrt(V["mpr_lag1", "mpr_lag1"])
  ) %>%
    mutate(statistic = estimate / std.error,
           p.value = 2 * pnorm(abs(statistic), lower.tail = FALSE),
           stars = stars(p.value),
           term_label = clean_term(term),
           reported_scale = "short-run rho")

  terms_lr <- setdiff(names(b), "mpr_lag1")

  lr <- purrr::map_dfr(terms_lr, function(v) {
    gradient <- rep(0, length(b)); names(gradient) <- names(b)
    gradient[v] <- 1 / (1 - rho)
    gradient["mpr_lag1"] <- b[[v]] / (1 - rho)^2

    est <- b[[v]] / (1 - rho)
    se  <- sqrt(as.numeric(t(gradient) %*% V %*% gradient))

    tibble::tibble(term = v,
           estimate = est,
           std.error = se,
           statistic = est / se,
           p.value = 2 * pnorm(abs(statistic), lower.tail = FALSE),
           stars = stars(p.value),
           term_label = clean_term(term),
           reported_scale = "long-run beta/(1-rho)")
  })

  dplyr::bind_rows(smoothing, lr)
}

phi_at_debt <- function(model, debt_values, model_label = "modelo") {
  b <- stats::coef(model)
  V <- vcov_table(model)
  rho <- coef_required(b, "mpr_lag1", model_label)
  beta_pi <- coef_required(b, "inflation", model_label)
  has_interaction <- "debt_x_inf" %in% names(b)

  purrr::map_dfr(names(debt_values), function(pp) {
    z <- as.numeric(debt_values[[pp]])
    numerator <- beta_pi + if (has_interaction) z * b[["debt_x_inf"]] else 0
    est <- numerator / (1 - rho)

    gradient <- rep(0, length(b)); names(gradient) <- names(b)
    gradient["inflation"] <- 1 / (1 - rho)
    if (has_interaction) gradient["debt_x_inf"] <- z / (1 - rho)
    gradient["mpr_lag1"] <- numerator / (1 - rho)^2

    se <- sqrt(as.numeric(t(gradient) %*% V %*% gradient))

    tibble::tibble(debt_percentile = pp,
           debt_value = z,
           estimate = est,
           std.error = se,
           statistic = est / se,
           p.value = 2 * pnorm(abs(statistic), lower.tail = FALSE),
           stars = stars(p.value))
  })
}

slope_differential <- function(model, debt_values, triple_term, model_label = "modelo") {
  b <- stats::coef(model)
  V <- vcov_table(model)
  rho <- coef_required(b, "mpr_lag1", model_label)
  gamma <- coef_required(b, triple_term, model_label)

  purrr::map_dfr(names(debt_values), function(pp) {
    z <- as.numeric(debt_values[[pp]])
    est <- z * gamma / (1 - rho)

    gradient <- rep(0, length(b)); names(gradient) <- names(b)
    gradient[triple_term] <- z / (1 - rho)
    gradient["mpr_lag1"] <- z * gamma / (1 - rho)^2

    se <- sqrt(as.numeric(t(gradient) %*% V %*% gradient))

    tibble::tibble(debt_percentile = pp,
           debt_value = z,
           estimate = est,
           std.error = se,
           statistic = est / se,
           p.value = 2 * pnorm(abs(statistic), lower.tail = FALSE),
           stars = stars(p.value))
  })
}

fit_stats <- function(models) {
  purrr::imap_dfr(models, function(m, i) {
    e <- as.numeric(stats::residuals(m))
    n <- length(e)
    rss <- sum(e^2, na.rm = TRUE)
    k_coef <- length(stats::coef(m))
    k_fe <- length(plm::fixef(m))
    k_total <- k_coef + k_fe

    tibble::tibble(
      model = i,
      r2 = summary(m)$r.squared[["rsq"]],
      adj_r2 = summary(m)$r.squared[["adjrsq"]],
      nobs = stats::nobs(m),
      AIC_eviews_style = log(rss / n) + 2 * k_total / n,
      BIC_eviews_style = log(rss / n) + log(n) * k_total / n,
      sigma = sqrt(rss / stats::df.residual(m))
    )
  })
}

save_outputs <- function(prefix, panelA, panelB, fit) {
  utils::write.csv(panelA, file.path(out_dir, paste0(prefix, "_panelA_long_run.csv")), row.names = FALSE)
  utils::write.csv(panelB, file.path(out_dir, paste0(prefix, "_panelB_marginal_effects.csv")), row.names = FALSE)
  utils::write.csv(fit,    file.path(out_dir, paste0(prefix, "_fit_statistics.csv")), row.names = FALSE)
}

# ---------------- CARGA DE DATOS ----------------
stop_if_missing_file(file_xlsx)

advanced <- make_panel("Advanced")
emerging <- make_panel("Emerging")

debt_percentiles <- list(
  advanced = get_debt_percentiles_raw("Advanced"),
  emerging = get_debt_percentiles_raw("Emerging")
)

saveRDS(advanced, file.path(out_dir, "advanced_prepared_panel.rds"))
saveRDS(emerging, file.path(out_dir, "emerging_prepared_panel.rds"))
saveRDS(debt_percentiles, file.path(out_dir, "debt_percentiles_raw_sheet.rds"))

quality_checks <- tibble::tibble(
  sample = c("Advanced", "Emerging"),
  countries = c(length(unique(as.character(advanced$country))), length(unique(as.character(emerging$country)))),
  regression_rows_after_one_lag = c(nrow(advanced), nrow(emerging)),
  p25_debt = c(as.numeric(debt_percentiles$advanced[1]), as.numeric(debt_percentiles$emerging[1])),
  p50_debt = c(as.numeric(debt_percentiles$advanced[2]), as.numeric(debt_percentiles$emerging[2])),
  p75_debt = c(as.numeric(debt_percentiles$advanced[3]), as.numeric(debt_percentiles$emerging[3])),
  output_gap_source = ifelse(USE_EXCEL_OUTPUTGAP, "Excel OUTPUTGAP", "R HP filter from log(GDP)"),
  vcov_method = VCOV_METHOD
)
utils::write.csv(quality_checks, file.path(out_dir, "00_quality_checks.csv"), row.names = FALSE)

print(quality_checks)
message("00_setup_data.R completo.")
